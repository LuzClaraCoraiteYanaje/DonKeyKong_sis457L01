// Copyright Epic Games, Inc. All Rights Reserved.

#include "DonKeyKong_sis457EX.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, DonKeyKong_sis457EX, "DonKeyKong_sis457EX" );
 